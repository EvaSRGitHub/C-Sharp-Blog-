﻿$("#button").on("click", function () {
    $("body").scrollTop(0);
});